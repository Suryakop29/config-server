from airflow.sdk import dag, task, Param
import pendulum

@dag(
    dag_id="00_taskflow_with_param_demo",
    dag_display_name="00 TaskFlow Demo with Param",
    schedule="@daily",
    start_date=pendulum.datetime(2023, 1, 1, tz="UTC"),
    catchup=False,
    tags=["demo", "taskflow", "param"],
    params={
        "user_name": Param(
            default="Grace Hopper",
            type="string",
            description="Name of the user to greet"
        )
    },
)
def taskflow_with_param_demo():
    @task
    def fetch_user_id():
        return 100

    @task
    def fetch_user_profile(user_id: int, user_name: str):
        return {"id": user_id, "name": user_name}

    @task
    def send_welcome_email(profile: dict):
        print(f">>>> $$$$$ Sending welcome email to: {profile['name']} (user #{profile['id']})")

    user_id = fetch_user_id()
    profile = fetch_user_profile(user_id, user_name="{{ params.user_name }}")
    send_welcome_email(profile)

taskflow_with_param_demo()
