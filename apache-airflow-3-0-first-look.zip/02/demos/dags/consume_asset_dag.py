from airflow.sdk import Asset, dag, task
import pendulum

@dag(
    dag_id="00_consume_demo_asset",
    schedule=Asset(uri="file:///tmp/demo_asset.txt"),
    start_date=pendulum.datetime(2021, 1, 1, tz="UTC"),
    catchup=False,
    tags=["asset", "consumer"],
)
def consume_asset():
    @task
    def consume():
        print("Reacting to asset update: file:///tmp/demo_asset.txt")
        with open("/tmp/demo_asset.txt", "r") as f:
            print("File content:")
            print(f.read())

    consume()

consume_asset()
