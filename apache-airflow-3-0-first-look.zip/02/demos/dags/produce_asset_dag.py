from airflow.sdk import dag, task, Asset
import pendulum

# Define the asset to be emitted
demo_asset = Asset(uri="file:///tmp/demo_asset.txt")

# Define a real DAG that produces it
@dag(
    dag_id="00_produce_demo_asset",
    schedule="@daily",
    start_date=pendulum.datetime(2021, 1, 1, tz="UTC"),
    catchup=False,
    tags=["demo", "asset"]
)
def asset_producer_dag():
    @task(outlets=[demo_asset])
    def produce():
        with open("/tmp/demo_asset.txt", "w") as f:
            f.write("Hello from the DAG\n")
        print("Wrote to asset: /tmp/demo_asset.txt")

    produce()

asset_producer_dag()
