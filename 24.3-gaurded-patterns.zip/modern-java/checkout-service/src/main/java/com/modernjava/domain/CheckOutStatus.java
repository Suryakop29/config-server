package com.modernjava.domain;

public enum CheckOutStatus {
    SUCCESS,
    FAILURE
}
